#Roberto Carlos Iglesias Álvarez U20230727
#Ejercicio 1

suma = 0

for i in range(1, 101):
    suma += i

print("La suma del 1 al 100 es:", suma)