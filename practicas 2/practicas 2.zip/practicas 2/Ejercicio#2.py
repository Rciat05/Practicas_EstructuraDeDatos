#Ejercicio 2

palabra = "Hola, estoy programando en python!!!"

Vocales = ['a','e','i','o','u']

for vocal in Vocales:
    print (vocal, palabra.count(vocal))