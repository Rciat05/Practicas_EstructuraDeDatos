# #declaracion de diccionarios

# MiDiccionario =  dict()

# otroDiccionario={}

# otraFormaDeclaracion={
#     'clave1': 10, 
#     1: True,
#     'otraclave':[1,2,3],
#     'cadena' : 'Este es un mensaje',
#     'diccionario' : MiDiccionario,
# }

# #print(otraFormaDeclaracion)
# # print(otraFormaDeclaracion['clave1'])
# # print(otraFormaDeclaracion[1])
# # print(otraFormaDeclaracion['otraclave'])
# # # print(otraFormaDeclaracion['diccionario']

# #Limpiar

# copia = otraFormaDeclaracion.copy()
# print(otraFormaDeclaracion)
# print(copia)


# persona = {
#     'nombres' :'Jouse Isai',
#     'apellidos' : 'Herrera Benitez'
# }

# notas = dict.formkeys(claves)
# # print(persona.get('nombres'))
# # print(persona['apellidos'])

# claves = ('nota1', 'nota2', 'nota3', 'nota4')
# # notas=dict.fromkeys(claves)
# # print(notas.get('nota4'))

# print(persona.keys)
# print(persona.values)

# persona.pop('apellido')
# print(persona)
